import 'variant.dart';

class Product {
  final int id;
  final int categoryId;
  final String name;
  final String image; // ürün ana görseli/emoji
  final List<ProductVariant> variants;

  const Product({
    required this.id,
    required this.categoryId,
    required this.name,
    required this.image,
    required this.variants,
  });

  ProductVariant get defaultVariant => variants.first;

  factory Product.fromJson(Map<String, dynamic> j) => Product(
        id: j['id'],
        categoryId: j['category_id'],
        name: j['name'],
        image: j['image'] ?? '🛒',
        variants: (j['variants'] as List<dynamic>?)
                ?.map((e) => ProductVariant.fromJson(e))
                .toList() ??
            // geriye dönük uyumluluk: eski price/unit'ten tek varyant üret
            [
              ProductVariant(
                id: j['id'] * 1000, // sentetik id
                name: 'Standart',
                price: (j['price'] as num).toDouble(),
                unit: j['unit'],
                image: j['image'],
              )
            ],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'category_id': categoryId,
        'name': name,
        'image': image,
        'variants': variants.map((v) => v.toJson()).toList(),
      };
}
