class ProductVariant {
  final int id;
  final String name;
  final double price;
  final String unit;
  final String? sku;
  final String? image; // opsiyonel, ürün varyanta özel görsel

  const ProductVariant({
    required this.id,
    required this.name,
    required this.price,
    required this.unit,
    this.sku,
    this.image,
  });

  factory ProductVariant.fromJson(Map<String, dynamic> j) => ProductVariant(
        id: j['id'],
        name: j['name'],
        price: (j['price'] as num).toDouble(),
        unit: j['unit'],
        sku: j['sku'],
        image: j['image'],
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'price': price,
        'unit': unit,
        if (sku != null) 'sku': sku,
        if (image != null) 'image': image,
      };
}
