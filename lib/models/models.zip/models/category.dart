class Category {
  final int id;
  final String name;
  final String image;
  const Category({required this.id, required this.name, required this.image});

  factory Category.fromJson(Map<String, dynamic> j) =>
      Category(id: j["id"], name: j["name"], image: j["image"] ?? "🛒");

  Map<String, dynamic> toJson() => {"id": id, "name": name, "image": image};
}
